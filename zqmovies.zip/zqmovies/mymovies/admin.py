from django.contrib import admin
from mymovies.models import Movie ,contact

# Register your models here.
class main(admin.ModelAdmin):
    fields = ('Category','Movies_tittle','trailer','myurl','server_1','server_2','Movies2_img','Movies_img','Mov_Description')

admin.site.site_header = "The ZQMOVIES"
admin.site.index_title = "The ZQMOVIES Administration"
admin.site.site_title = "The ZQMOVIES Admin"
admin.site.register(Movie, main)
admin.site.register(contact)
